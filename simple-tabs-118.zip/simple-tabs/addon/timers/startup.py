import bpy


def startup_timer():
    bpy.ops.simpletabs.update()
